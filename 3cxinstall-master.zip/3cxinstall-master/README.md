# 3cxinstall
Quick install of 3CX CLI


sudo apt-get update && sudo apt-get install git -y && git clone https://github.com/febo01/3cxinstall && cd 3cxinstall && sudo chmod +x install.sh | bash ./install.sh


